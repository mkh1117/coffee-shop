from django.contrib import messages
from django.http import JsonResponse
from django.shortcuts import redirect, render
from django.utils.http import url_has_allowed_host_and_scheme
from django.views.decorators.http import require_POST


def _safe_positive_int(value, default=1):
    try:
        number = int(value)
    except (TypeError, ValueError):
        return default
    return number if number > 0 else default


def _cart_count(cart):
    total = 0
    for item in cart.values():
        total += int(item.get('quantity', 0))
    return total


def cart_detail(request):
    cart = request.session.get('cart', {})
    cart_items = []
    total_price = 0

    for key, item in cart.items():
        quantity = int(item.get('quantity', 0))
        price = int(item.get('price', 0))
        item_total = price * quantity
        total_price += item_total

        cart_items.append({
            'key': key,
            'name': item.get('name', ''),
            'price': price,
            'image': item.get('image', ''),
            'product_type': item.get('product_type', ''),
            'quantity': quantity,
            'item_total': item_total,
        })

    return render(request, 'cart/cart.html', {
        'cart_items': cart_items,
        'total_price': total_price,
    })


@require_POST
def add_to_cart(request):
    name = request.POST.get('name', '').strip()
    price = request.POST.get('price', '0').strip()
    image = request.POST.get('image', '').strip()
    product_type = request.POST.get('product_type', 'item').strip()
    quantity = _safe_positive_int(request.POST.get('quantity'), default=1)

    if not name:
        return redirect('cart:cart_detail')

    try:
        price = int(price)
    except ValueError:
        price = 0

    cart = request.session.get('cart', {})
    item_key = f'{product_type}-{name}'

    if item_key in cart:
        cart[item_key]['quantity'] += quantity
    else:
        cart[item_key] = {
            'name': name,
            'price': price,
            'image': image,
            'product_type': product_type,
            'quantity': quantity,
        }

    request.session['cart'] = cart
    request.session.modified = True

    new_count = _cart_count(cart)
    message_text = 'برای پرداخت نهایی روی آیکن سبد خرید بزنید.'

    if request.headers.get('x-requested-with') == 'XMLHttpRequest':
        return JsonResponse({
            'ok': True,
            'cart_count': new_count,
            'message': message_text,
        })

    messages.success(request, message_text, extra_tags='cart-added')

    next_url = request.POST.get('next') or request.META.get('HTTP_REFERER')
    if next_url and url_has_allowed_host_and_scheme(next_url, allowed_hosts={request.get_host()}):
        return redirect(next_url)

    return redirect('cart:cart_detail')


@require_POST
def remove_from_cart(request, item_key):
    cart = request.session.get('cart', {})

    if item_key in cart:
        removed_name = cart[item_key].get('name', 'محصول')
        del cart[item_key]
        request.session['cart'] = cart
        request.session.modified = True
        messages.success(request, f'{removed_name} از سبد خرید حذف شد.')

    return redirect('cart:cart_detail')
