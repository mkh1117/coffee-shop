def cart_counter(request):
    cart = request.session.get('cart', {})
    cart_count = 0

    for item in cart.values():
        cart_count += int(item.get('quantity', 0))

    return {'cart_count': cart_count}
