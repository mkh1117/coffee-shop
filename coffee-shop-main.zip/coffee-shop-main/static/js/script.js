const searchBtn = document.getElementById('search-btn');
const searchForm = document.querySelector('.search-form');

if(searchBtn){
    searchBtn.addEventListener('click', () => {
        searchForm.classList.toggle('active');
    });
}

const modal = document.getElementById("modal");
const openBtn = document.getElementById("openModalBtn");
const closeBtn = document.getElementById("closeModalBtn");

if(openBtn){
    openBtn.onclick = () => {
        modal.classList.add("active");
    }
}

if(closeBtn){
    closeBtn.onclick = () => {
        modal.classList.remove("active");
    }
}

window.onclick = (e) => {
    if(e.target === modal){
        modal.classList.remove("active");
    }
}

const signUpButton = document.getElementById('signUp');
const signInButton = document.getElementById('signIn');
const container = document.getElementById('container');

if(signUpButton){
    signUpButton.addEventListener('click', () => {
        container.classList.add("right-panel-active");
    });
}

if(signInButton){
    signInButton.addEventListener('click', () => {
        container.classList.remove("right-panel-active");
    });
}
// Add products to cart without leaving the menu/product page
const cartForms = document.querySelectorAll('.add-cart-form');
const cartCountBadge = document.querySelector('.cart-count');
const cartHint = document.getElementById('cart-hint');
let cartHintTimer = null;

function showCartHint(message){
    if(!cartHint){
        return;
    }

    cartHint.textContent = message || 'برای پرداخت نهایی روی آیکن سبد خرید بزنید.';
    cartHint.classList.add('show');

    clearTimeout(cartHintTimer);
    cartHintTimer = setTimeout(() => {
        cartHint.classList.remove('show');
        cartHint.textContent = '';
    }, 4500);
}

cartForms.forEach((form) => {
    form.addEventListener('submit', function(e){
        e.preventDefault();

        const currentScrollY = window.scrollY;
        const submitButton = form.querySelector('.add-cart-icon');
        const formData = new FormData(form);

        if(submitButton){
            submitButton.disabled = true;
        }

        fetch(form.action, {
            method: 'POST',
            body: formData,
            headers: {
                'X-Requested-With': 'XMLHttpRequest'
            },
            credentials: 'same-origin'
        })
        .then((response) => response.json())
        .then((data) => {
            if(data.ok){
                if(cartCountBadge){
                    cartCountBadge.textContent = data.cart_count;
                }
                showCartHint(data.message);
            }else{
                showCartHint('محصول اضافه نشد؛ دوباره امتحان کنید.');
            }
        })
        .catch(() => {
            showCartHint('محصول اضافه نشد؛ دوباره امتحان کنید.');
        })
        .finally(() => {
            window.scrollTo({ top: currentScrollY, left: 0, behavior: 'auto' });
            if(submitButton){
                submitButton.disabled = false;
            }
        });
    });
});
